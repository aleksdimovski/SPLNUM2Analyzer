features int[0,2] A1;
features int[0,2] A2;
features int[0,2] A3;
features int[0,2] A4;
features int[0,2] A5;
features int[0,2] A6;
features int[0,2] A7;
features int[0,2] A8;
features int[0,2] A9;
features int[0,2] A10;
features int[0,2] A11;
features int[0,2] A12;
features int[0,2] A13;
features int[0,2] A14;

int main() {
  int i=0;

  #if (A1) i=1; #else i=0; #endif
  #if (A2) i=1; #else i=0; #endif
  #if (A3) i=1; #else i=0; #endif
  #if (A4) i=1; #else i=0; #endif
  #if (A5) i=1; #else i=0; #endif
  #if (A6) i=1; #else i=0; #endif	
  #if (A7) i=1; #else i=0; #endif	
  #if (A8) i=1; #else i=0; #endif
  #if (A9) i=1; #else i=0; #endif
  #if (A10) i=1; #else i=0; #endif
  #if (A11) i=1; #else i=0; #endif
  #if (A12) i=1; #else i=0; #endif
  #if (A13) i=1; #else i=0; #endif
  #if (A14) i=1; #else i=0; #endif	

  return 0;
}